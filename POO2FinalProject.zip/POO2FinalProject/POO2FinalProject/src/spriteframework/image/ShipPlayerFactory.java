package spriteframework.image;

import javax.swing.ImageIcon;
import java.awt.*;

public class ShipPlayerFactory implements PlayerFactory {


    @Override
    public Image createImage() {
        ImageIcon ii = new ImageIcon("images/player.png");
        Image image = ii.getImage().getScaledInstance(10, 10, Image.SCALE_DEFAULT);
        return image;
    }
}
