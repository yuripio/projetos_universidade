package spriteframework.sprite;

import javax.swing.ImageIcon;

import spriteframework.Commons;
import spriteframework.image.PlayerFactory;
import spriteframework.strategy.MovementStrategy;

import java.awt.Image;
import java.awt.event.KeyEvent;

public class Player extends Sprite {
    private MovementStrategy movementStrategy;
    private int width;
    private int boardWidth;
    private int lastDirectionX; // true para direita, false para esquerda
    private int lastDirectionY; // true para baixo, false para cima
    private PlayerFactory playerFactory;

    public void setBoardWidth(int boardWidth) {
        this.boardWidth = boardWidth;
    }

    public Player() {
        resetState();
    }

    public void setPlayerFactory(PlayerFactory factory) {
        this.playerFactory = factory;
        loadImage();
    }

    public void setImage(PlayerFactory player) {
        this.playerFactory = player;
        loadImage();
        getImageDimensions();
    }

    public void loadImage() {
        image = playerFactory.createImage();
        setImage(image);
    }

    public int getLastDirectionX() {
        return lastDirectionX;
    }

    public void setLastDirectionX(int lastDirectionX) {
        this.lastDirectionX = lastDirectionX;
    }

    public int getLastDirectionY() {
        return lastDirectionY;
    }

    public void setLastDirectionY(int lastDirectionY) {
        this.lastDirectionY = lastDirectionY;
    }

    public void setMovementStrategy(MovementStrategy strategy) {
        this.movementStrategy = strategy;
    }

    private boolean movingLeft;
    private boolean movingRight;
    private boolean movingUp;
    private boolean movingDown;

    // Getters e setters para as flags de movimento
    public boolean isMovingLeft() {
        return movingLeft;
    }

    public void setMovingLeft(boolean movingLeft) {
        this.movingLeft = movingLeft;
    }

    public boolean isMovingRight() {
        return movingRight;
    }

    public void setMovingRight(boolean movingRight) {
        this.movingRight = movingRight;
    }

    public boolean isMovingUp() {
        return movingUp;
    }

    public void setMovingUp(boolean movingUp) {
        this.movingUp = movingUp;
    }

    public boolean isMovingDown() {
        return movingDown;
    }

    public void setMovingDown(boolean movingDown) {
        this.movingDown = movingDown;
    }

    public void act() {

        x += dx;

        if (x <= 2) {

            x = 2;
        }

        if (x >= boardWidth - 2 * width) {

            x = boardWidth - 2 * width;
        }
    }

    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_UP || key == KeyEvent.VK_DOWN) {
            if (movementStrategy != null) {
                if (key == KeyEvent.VK_LEFT) {
                    movementStrategy.moveLeft(this);
                } else if (key == KeyEvent.VK_RIGHT) {
                    movementStrategy.moveRight(this);
                } else if (key == KeyEvent.VK_UP) {
                    movementStrategy.moveUp(this);
                } else if (key == KeyEvent.VK_DOWN) {
                    movementStrategy.moveDown(this);
                }
            }
        }
    }

    public void keyReleased(KeyEvent e) {

        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT) {

            dx = 0;
        }

        if (key == KeyEvent.VK_RIGHT) {

            dx = 0;
        }
    }

    private void resetState() {

        setX(Commons.INIT_PLAYER_X);
        setY(Commons.INIT_PLAYER_Y);
    }
}
