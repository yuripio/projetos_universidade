package freezemonsters;

import java.awt.EventQueue;

import spriteframework.AbstractBoard;
import spriteframework.MainFrame;
import spriteframework.image.CowboyPlayerFactory;
import spriteframework.strategy.VerticalHorizontalMovementStrategy;
import spriteframework.sprite.Player;

public class FreezeMonstersGame extends MainFrame {

	public FreezeMonstersGame() {
		super("Freeze Monsters", 600, 600, 550);
	}

	protected AbstractBoard createBoard(int width, int height, int ground) {
		FreezeMonstersBoard board = new FreezeMonstersBoard(width, height, ground);
		Player player = board.getPlayer(0);
		player.setBoardWidth(width);
		player.setMovementStrategy(new VerticalHorizontalMovementStrategy());
		player.setPlayerFactory(new CowboyPlayerFactory());

		return board;
	}

	public static void main(String[] args) {

		EventQueue.invokeLater(() -> {

			new FreezeMonstersGame();
		});
	}

}
