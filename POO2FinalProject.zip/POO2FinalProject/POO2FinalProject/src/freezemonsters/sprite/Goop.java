package freezemonsters.sprite;

import java.awt.Image;

import javax.swing.ImageIcon;

import spriteframework.sprite.BadSprite;

public class Goop extends BadSprite {

    private boolean destroyed;
    private int directionX;
    private int directionY;

    public Goop(int x, int y) {
        initGoop(x, y);
    }

    private void initGoop(int x, int y) {
        setDestroyed(true);

        this.x = x;
        this.y = y;

        String goopImg = "images/gosma.png";
        ImageIcon ii = new ImageIcon(goopImg);
        Image image = ii.getImage().getScaledInstance(15, 15, Image.SCALE_DEFAULT);
        setImage(image);

        this.directionX = 0;
        this.directionY = 0;
    }

    public void setDestroyed(boolean destroyed) {
        this.destroyed = destroyed;
    }

    public boolean isDestroyed() {
        return destroyed;
    }

    public int getDirectionX() {
        return directionX;
    }

    public void setDirectionX(int directionX) {
        this.directionX = directionX;
    }

    public int getDirectionY() {
        return directionY;
    }

    public void setDirectionY(int directionY) {
        this.directionY = directionY;
    }
}
