package freezemonsters.sprite;

import java.awt.Image;
import java.util.LinkedList;

import javax.swing.ImageIcon;

import spriteframework.sprite.BadSprite;
import spriteframework.sprite.BadnessBoxSprite;

public class MonsterSprite extends BadnessBoxSprite {

    private Goop goop;
    private String monster;
    private int monsterIndex;
    private Image imageFrozen; // Adicionando campo para armazenar a imagem congelada do monstro

    public MonsterSprite(int x, int y, String monster, int monsterIndex) {
        this.monster = monster;
        this.monsterIndex = monsterIndex;
        initMonster(x, y, monster);
    }

    public int getMonsterIndex() {
        return monsterIndex;
    }

    private void initMonster(int x, int y, String monster) {
        this.x = x;
        this.y = y;

        goop = new Goop(x, y);

        // Carregar imagem normal do monstro
        ImageIcon ii = new ImageIcon(monster);
        Image image = ii.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
        setImage(image);

        // Carregar imagem congelada do monstro
        ImageIcon iiFrozen = new ImageIcon(monster.replace(".png", "bg.png")); // Substitui ".png" por "bg.png"
        imageFrozen = iiFrozen.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
    }

    public Goop getGoop() {
        return goop;
    }

    public void setGoop(Goop goop) {
        this.goop = goop;
    }


    public Image getImageFrozen() { // Método para obter a imagem congelada do monstro
        return imageFrozen;
    }

    @Override
    public LinkedList<BadSprite> getBadnesses() {
        LinkedList<BadSprite> aGoop = new LinkedList<BadSprite>();
        aGoop.add(goop);
        return aGoop;
    }
}
